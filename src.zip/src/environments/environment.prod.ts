export const environment = {
  production: true,
  BaseUrl:"https://digital-lab.lu/pick-up/admin/app/"
};
