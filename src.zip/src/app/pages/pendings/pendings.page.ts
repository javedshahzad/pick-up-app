import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pendings',
  templateUrl: './pendings.page.html',
  styleUrls: ['./pendings.page.scss'],
})
export class PendingsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
